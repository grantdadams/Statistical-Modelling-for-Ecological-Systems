Test<-function() 
{ 
 MaxAge <- 20    
 M <- 0.15 
# M <- 0.2
     
 TheData <- scan("D:\\courses\\FISH 559_20\\Homes\\Ahome3\\Home3.Txt",what=list(Age=0,Fecu=0,Wght1=0,Wght2=0,Sel1=0,Sel2=0),skip=1,n=(MaxAge+1)*6) 
 Fecund <- TheData$Fecu 
 Sel <- matrix(rep(1,(MaxAge+1)*2),nrow=2)   
 Sel[1,] <- TheData$Sel1 
 Sel[2,] <- TheData$Sel2 
 Wght <- matrix(rep(1,(MaxAge+1)*2),nrow=2)  
 Wght[1,] <- TheData$Wght1 
 Wght[2,] <- TheData$Wght2 
 
 # test code 
 SRModel = 3 
 GammaV = 2.39
 Steep = 0.5 
 R0 <- 1
 
# Find the spanwer biomass in the absence of exploitation 
 Vals <- NumAge(M,Sel,0.0,MaxAge,Wght,Fecund) 
 SBPRF0 <- Vals$SPR 
 print(SBPRF0)
 print(Vals)
 AA

  Vals <- NumAge(M,Sel,0.0,MaxAge,Wght,Fecund) 
# print(Vals) 
 
 Vals <- NumAge(M,Sel,0.1,MaxAge,Wght,Fecund) 
 print(Vals) 
 Vals <- NumAge(M,Sel,0.3,MaxAge,Wght,Fecund) 
 #print(Vals) 

# Compute and store Alpha and Beta for this stock-recruitment relationship 
 RetVal <- GetAlphaBeta(SBPRF0,SRModel,Steep,R0,GammaV) 
 Alpha <- RetVal$Alpha 
 Beta <-RetVal$Beta 
 
 R0 = 1 
 Fv <- 0 
 Vals <- ComputeYield(M,Sel,Fv,MaxAge,Wght,Fecund,R0,SBPRF0,SRModel,Alpha,Beta,GammaV,SBPRF0*R0) 
# print(Vals) 
 Fv <- 0.2 
 Vals <- ComputeYield(M,Sel,Fv,MaxAge,Wght,Fecund,R0,SBPRF0,SRModel,Alpha,Beta,GammaV,SBPRF0*R0) 
 #print(Vals) 
 AA
 
     
 # Question 3 
 Val1 <- FindF(M,MaxAge,1,0.5,1,T,Wght,Sel,Fecund)    
 Val1 <- FindF(M,MaxAge,2,0.5,1,T,Wght,Sel,Fecund)    
 Val1 <- FindF(M,MaxAge,3,0.5,1,T,Wght,Sel,Fecund,GammaV=2.39)    

 # Question 4 
 par(mfrow=c(3,4)) 
 PlotTrade(M,MaxAge,1,0.25,0.95,1,Wght,Sel,Fecund) 
 PlotTrade(M,MaxAge,2,0.25,0.95,1,Wght,Sel,Fecund) 
 PlotTrade(M,MaxAge,3,0.25,0.95,1,Wght,Sel,Fecund,GammaV=2.39) 
 NULL 
} 
 
# ============================================================================================================================================================================ 
 
PlotTrade<-function(M,MaxAge,SRModel,Minh,Maxh,R0,Wght,Sel,Fecund,GammaV=1) 
{ 
 Steeps <- NULL  
 Fcrh <- NULL 
 SSMSY <- NULL 
 MSY <- NULL 
 FMSY <- NULL 
 for (Ival in 1:15) 
  { 
    Steep = Minh + (Maxh-Minh)/14*(Ival-1) 
    Vals <- FindF(M,MaxAge,SRModel,Steep,1,F,Wght,Sel,Fecund,GammaV)    
    Steeps <- c(Steeps,Steep) 
    Fcrh <- c(Fcrh,Vals$Fcrash) 
    SSMSY <- c(SSMSY,Vals$SSMSY) 
    MSY <- c(MSY,Vals$MSY) 
    FMSY <- c(FMSY,Vals$FMSY) 
  } 
  
 print(Steeps) 
 print(SSMSY) 
 plot(Steeps,Fcrh,xlab="Steepness",ylab="Fcrash",type='b',lwd=2,lty=1) 
 plot(Steeps,FMSY,xlab="Steepness",ylab="F(MSY)",type='b',lwd=2,lty=1) 
 plot(Steeps,MSY,xlab="Steepness",ylab="MSY",type='b',lwd=2,lty=1) 
 plot(Steeps,SSMSY,xlab="Steepness",ylab="SMSY/S0 (%)",type='b',lwd=2,lty=1,ylim=c(0,100)) 
     
} 
 
# ============================================================================================================================================================================ 
 
FindF<-function(M,MaxAge,SRModel,Steep,R0,DoPrint,Wght,Sel,Fecu,GammaV=1) 
{ 
 
# Find the spanwer biomass in the absence of exploitation 
 Vals <- NumAge(M,Sel,0.0,MaxAge,Wght,Fecu) 
 SBPRF0 <- Vals$SPR 
 
# Compute and store Alpha and Beta for this stock-recruitment relationship 
 RetVal <- GetAlphaBeta(SBPRF0,SRModel,Steep,R0,GammaV) 
 Alpha <- RetVal$Alpha 
 Beta <-RetVal$Beta 
 
# Calculate Yield and SSB for a range of Fs 
 FishMort <- NULL 
 Yield <- NULL 
 Spawn <- NULL 
 Recs <- NULL 
 Fval <- 1 
 repeat 
  { 
#  Set up the fishing mortality and compute the yield-per-recruit / spawning biomass-per-recruit     
    Fv <- (Fval-1)*0.01 
   Vals <- ComputeYield(M,Sel,Fv,MaxAge,Wght,Fecu,R0,SBPRF0,SRModel,Alpha,Beta,GammaV,SBPRF0*R0) 
 
#  Store the results     
   Recs <- c(Recs,Vals$Rec) 
   FishMort <- c(FishMort,Fv) 
    Yield <- c(Yield,Vals$Yld) 
    Spawn <- c(Spawn,Vals$Spn) 
    if (Vals$Yld < 0) break 
    Fval <- Fval+1 
  } 
 MaxFs <- Fval 
 #print(Yield)
 #print(Spawn)
 #print(Recs)
 #print(FishMort)
 
 # Find Fmsy (get an initial value) 
 BestF <- 0;  BestY <- 0; CrashF <- 0 
 for (Fval in 2:MaxFs) 
  { 
   if (Yield[Fval] > BestY)  
    { 
      BestY <- Yield[Fval] 
      BestF <- (Fval-1)*0.01 
    } 
   if (Spawn[Fval-1] >0 & Spawn[Fval] < 0) 
    CrashF <- (Fval-1)*0.01 
  }  
 minF <- BestF-0.01 
 maxF <- BestF+0.01 
 repeat { 
    FMSY <- (minF+maxF)/2.0  
    Yr1 <- ComputeYield(M,Sel,FMSY+0.001,MaxAge,Wght,Fecu,R0,SBPRF0,SRModel,Alpha,Beta,GammaV,SBPRF0*R0)  
    Yr2 <- ComputeYield(M,Sel,FMSY-0.001,MaxAge,Wght,Fecu,R0,SBPRF0,SRModel,Alpha,Beta,GammaV,SBPRF0*R0)  
    Y1 <- Yr1$Yld 
    Y2 <- Yr2$Yld 
    S1 <- Yr1$Spn 
    S2 <- Yr2$Spn 
    Deriv <- (Y1-Y2)/0.002 
    MSY <- (Y1+Y2)/2.0 
    if (Deriv > 0)  
     minF = FMSY 
    else 
     maxF = FMSY     
    if (abs(Deriv) < 0.0001) break 
  } 
 SS0 <- (S1+S2)/2.0 
 
# Find F(crash) 
 minF <- CrashF-0.01 
 maxF <- CrashF 
 repeat { 
    Fcrash <- (minF+maxF)/2.0 
    Yr <- ComputeYield(M,Sel,Fcrash,MaxAge,Wght,Fecu,R0,SBPRF0,SRModel,Alpha,Beta,GammaV,SBPRF0*R0)  
    S1 <- Yr$Spn 
    if (abs(S1  )<0.00001) break 
    if (S1 > 0) 
     minF <- Fcrash 
    else 
     maxF <- Fcrash 
    } 
 
 
 # Final outcomes (print if needed) 
 if (DoPrint) 
 { 
  cat("FMSY ",round(FMSY,4),"\n") 
  cat("MSY ",round(MSY,4),"\n") 
  cat("SMSY/S0(%) ",round(SS0,2),"\n") 
  cat("Fcrash ",round(Fcrash,4),"\n") 
 
  par(mfrow=c(2,2)) 
  ymax1 <- max(Yield) 
  ymax2 <- max(Spawn) 
  ymax3 <- max(Recs) 
  ymax4 <- Fcrash*1.2 
 par(xaxs='i',yaxs='i') 
  tit <- paste("Steep =",Steep) 
  plot(Spawn,Yield,type='l',lty=1,xlim=c(0,ymax2*1.1),ylim=c(0,ymax1*1.1),xlab="Spawning biomass (%)",ylab="Yield",lwd=2,axes=F) 
  axis(1,xaxs="s") 
  axis(2,yaxs="s") 
  mtext(tit,side=3,outer=F,line=0.5,adj=0,csi=0.2) 
  plot(FishMort,Spawn,type='l',lty=1,xlim=c(0,ymax4),ylim=c(0,ymax2*1.1),xlab="Fishing mortality",ylab="Spawning Biomass (%)",lwd=2,axes=F) 
  axis(1,xaxs="s") 
  axis(2,yaxs="s") 
  plot(FishMort,Yield,type='l',lty=1,xlim=c(0,ymax4),ylim=c(0,ymax1*1.1),xlab="Fishing mortality",ylab="Yield",lwd=2,axes=F) 
  axis(1,xaxs="s") 
  axis(2,yaxs="s") 
  plot(Spawn,Recs,type='l',lty=1,xlim=c(0,ymax2*1.1),ylim=c(0,ymax3*1.1),xlab="Spawning biomass (%)",ylab="Recruitment (%)",lwd=2,axes=F) 
  axis(1,xaxs="s") 
  axis(2,yaxs="s") 
  abline(0,1,lty=2) 
  lines(c(20,20,0),c(0,Steep*100,Steep*100),lty=3,lwd=2) 
 # plot(FishMort,Recs,type='l',lty=1,xlim=c(0,ymax4),ylim=c(0,ymax3*1.1),xlab="Fishing mortality",ylab="Recruitment (%)"lwd=2) 
} 
RetVals <- 0 
RetVals$FMSY <- FMSY 
RetVals$MSY <- MSY 
RetVals$SSMSY <- SS0 
RetVals$Fcrash <- Fcrash 
return(RetVals) 
 NULL 
 
} 
 
 
# ================================================================================================================================================================================= 
 
ComputeYield <- function(M,Sel,Fv,MaxAge,Wght,Fecu,R0,SBPRF0,SRModel,Alpha,Beta,GammaV,S0) 
{ 
 
# Find the yield-per-recruit and spawner biomass-per-recruit 
  Vals <- NumAge(M,Sel,Fv,MaxAge,Wght,Fecu) 
  SPR <- Vals$SPR 
  YPR <- Vals$YPR 
     
# Compute the recruitment 
  Recr <- GetRec(SPR,S0,SRModel,Alpha,Beta,GammaV) 
  cat(Fv,SPR,YPR,Recr,YPR*Recr,"\n")
 
# Store the results  
  RetVals <- NULL 
  RetVals$Rec <- Recr/R0*100 
  RetVals$Yld <- YPR*Recr 
  RetVals$Spn <- SPR*Recr/(SBPRF0*R0)*100 
  return(RetVals) 
} 
 
# ================================================================================================================================================================================= 
 
NumAge<-function(M,Sel,Fv,MaxAge,Wght,Fecu) 
{ 
 
# Set up the plus-group age 
  PlusAge <- MaxAge + 1 
 
# Create the N matrix and compute Z 
 N <- matrix(rep(0,PlusAge*2),nrow=2) 
 Z <- M + Sel * Fv 
 
# Compute the full age-structure 
 for (Sex in 1:2) 
  { 
    N[Sex,1] = 0.5 
    for (Age in 1:MaxAge) 
     N[Sex,Age+1] <- N[Sex,Age] * exp(-Z[Sex,Age]) 
    N[Sex,PlusAge] <- N[Sex,PlusAge] / (1.0 - exp(-Z[Sex,PlusAge])) 
  }  
 
 # Compute the yield-per-recruit and the spawner biomass-per-recruit 
 SPR <- 0 
 for (Age in 2:PlusAge)  
  SPR <- SPR + Fecu[Age]*N[1,Age] 
 YPR <- 0 
 for (Sex in 1:2) 
  for (Age in 1:PlusAge)  
   YPR <- YPR + Wght[Sex,Age]*Sel[Sex,Age]*Fv/Z[Sex,Age]*N[Sex,Age]*(1.0-exp(-Z[Sex,Age])) 
 
# Return results to the main progra, 
 RetVar <- NULL 
 RetVar$SPR <- SPR 
 RetVar$YPR <- YPR 
 RetVar$N <- N 
 return(RetVar) 
} 
 
# ================================================================================================================================================================================= 
 
GetRec <- function(SPR,S0,SRModel,Alpha,Beta,GammaV=1) 
{ 
  
# Beverton-Holt stock-recruitment relationship 
if (SRModel == 1) 
  RecOut <- (SPR-Alpha)/(Beta*SPR) 
 
# Ricker 
if (SRModel == 2) 
  RecOut <- log(Alpha*SPR)/(Beta*SPR) 
 
# Pella-Tomlinson 
if (SRModel == 3) 
 {
  Term1 <-(1-(1.0-Alpha*SPR)/(Beta*Alpha*SPR))
  if (Term1 > 0)
    RecOut <- S0/SPR*Term1^(1.0/GammaV)     
  else
    RecOut <- S0/SPR*Term1
 }     
 
return(RecOut) 
     
} 
 
# ================================================================================================================================================================================= 
 
GetAlphaBeta <- function(SPR0,SRModel,Steep,R0,GammaV) 
{ 
     
 # Beverton-Holt 
 if (SRModel == 1) 
  { 
    Alpha <- (1-Steep)/(4*Steep)*SPR0 
    Beta <- (5*Steep-1)/(4*Steep*R0) 
  } 
 
 # Ricker 
 if (SRModel == 2) 
 { 
   Beta = log(5.0*Steep)/(0.8*SPR0*R0) 
   Alpha = exp( log(5*Steep)/0.8 )/SPR0  
 } 
 
 # Pella-Tomlinson 
 if (SRModel == 3) 
  { 
    Alpha <- 1.0/SPR0 
    Beta <- (5*Steep-1)/(1.0-0.2^GammaV) 
  } 
 
 RetVals <- NULL     
 RetVals$Alpha <- Alpha 
 RetVals$Beta <- Beta 
 return(RetVals) 
} 
 
# ================================================================================================================================================================================= 
 
 Test() 
 
