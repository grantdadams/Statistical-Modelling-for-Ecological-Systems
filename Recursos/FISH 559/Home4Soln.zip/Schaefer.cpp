#include <TMB.hpp>

template <class Type> Type square(Type x){return x*x;}

template <class Type> Type PosFun2(Type x) {return sqrt(x*x); }

template <class Type> Type PosFun(Type x)
 {
  Type eps = 0.001;
  if (x > eps) return x;
  return eps/(2-x/eps);
 }

template<class Type>
Type objective_function<Type>::operator() ()
{
  DATA_INTEGER(Nyear)
  DATA_VECTOR(Catches)
  DATA_INTEGER(Nsurvey);
  DATA_IVECTOR(SurveyYear)
  DATA_VECTOR(AbundEst)
  DATA_VECTOR(AbundSD)
  DATA_INTEGER(Nproj)
  DATA_SCALAR(TheCatch)

  // End of data section

  PARAMETER(dummy);
  PARAMETER(Logr);
  PARAMETER(K);
  PARAMETER_VECTOR(Fval);

  int Yfinal;
  Yfinal = Nyear+Nproj+1;

  vector<Type> Biomass(Yfinal);
  vector<Type> CatHat(Nyear);
  Type Prior;
  Type rpar;
  Type Kpar;
  Type obj_fun;
  // End of the temporary variables

  rpar = exp(Logr);
  Kpar = K;

  // Prior on r
  Prior = 0.5*square(Logr + 1.2)/square(0.6);

  Biomass(0) = Kpar;
  for (int Iy=0;Iy<Nyear;Iy++)
   {
	if (Iy != 0)
	 CatHat(Iy) = exp(Fval(Iy-1))*Biomass(Iy);
	else
	 CatHat(Iy) = 0;
    Biomass(Iy+1) =  Biomass(Iy) + rpar*Biomass(Iy)*(1-Biomass(Iy)/Kpar) - CatHat(Iy);
    //std::cout << Iy+1 << " " <<  Biomass(Iy+1) << "\n";
    Prior += square(CatHat(Iy)-Catches(Iy))/(2.0*0.2*0.2);
   }

  obj_fun = Prior;
  int SurveyY;
  for (int Iy=0;Iy<Nsurvey;Iy++)
   {
    SurveyY = SurveyYear(Iy);
    obj_fun += 0.5*square(Biomass(SurveyY)-AbundEst(Iy))/square(AbundSD(Iy));
   }

  for (int Iy=Nyear;Iy<Yfinal-1;Iy++)
   {
    Biomass(Iy+1) =  Biomass(Iy) + rpar*Biomass(Iy)*(1-Biomass(Iy)/Kpar) - TheCatch;
   }

  obj_fun += dummy*dummy;

  REPORT(obj_fun);
  REPORT(Biomass);
  ADREPORT(rpar)

  return(obj_fun);
}
