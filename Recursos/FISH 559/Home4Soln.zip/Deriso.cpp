#include <TMB.hpp>

template <class Type> Type square(Type x){return x*x;}

template<class Type>
Type objective_function<Type>::operator() ()
{
  DATA_INTEGER(Nyear)
  DATA_VECTOR(Catches)
  DATA_INTEGER(Nsurvey);
  DATA_IVECTOR(SurveyYear)
  DATA_VECTOR(AbundEst)
  DATA_VECTOR(AbundSD)
  DATA_INTEGER(Nproj)
  DATA_SCALAR(TheCatch)
  DATA_SCALAR(Prow);
  DATA_SCALAR(Weight);
  DATA_SCALAR(Surv);

  // End of data section

  PARAMETER(dummy);
  PARAMETER(LogitSteep);
  PARAMETER(K);
  PARAMETER_VECTOR(Fval);

  int Yfinal;
  Yfinal = Nyear+Nproj+1;

  vector<Type> Biomass(Yfinal);
  vector<Type> Rec(Yfinal);
  vector<Type> S(Yfinal);
  vector<Type> CatHat(Nyear);

  Type Steep;
  Type Kpar;
  Type Numer;
  Type Denom;
  Type R0;
  Type Term1, Term2, Term3;
  int Lag,Lag1;

  Type Prior;
  Type obj_fun;
  // End of the temporary variables


  Steep = 0.2+0.8*exp(LogitSteep)/(1+exp(LogitSteep));
  Kpar = K;
  Prior = 0.5*square(LogitSteep-0.5108256)/square(2);

  Numer = 1-(1+Prow)*Surv+Prow*Surv*Surv;
  Denom = 1-Weight*Prow*Surv;
  R0 = Kpar*Numer/Denom;

  // Years 1 and 2 (these are special)
  Biomass(0) = Kpar;
  S(0) = Surv;
  CatHat(0) = 0;
  Rec(0) = 4*Steep*R0*Biomass(0)/Kpar/((1-Steep)+(5*Steep-1)*Biomass(0)/Kpar);
  Biomass(1) = (1+Prow)*S(0)*Biomass(0)-Prow*Surv*S(0)*Kpar-Prow*Weight*S(0)*R0+R0;
  Prior += square(CatHat(0)-Catches(0))/(2.0*0.2*0.2);

 for (int Iy=1;Iy<Nyear;Iy++)
  {
   // Survival and recruitment
   CatHat(Iy) = exp(Fval(Iy-1))*Biomass(Iy);
   S(Iy) = Surv*(1-exp(Fval(Iy-1)));
   Rec(Iy) = 4*Steep*R0*Biomass(Iy)/Kpar/((1-Steep)+(5*Steep-1)*Biomass(Iy)/Kpar);

   // Lag to recruitment
   if (Iy+1 - 5 < 0) Lag = 0; else Lag = Iy+1 - 5;
   if (Iy - 5 < 0) Lag1 = 0; else Lag1 = Iy - 5;

   // Update dynamics
   Term1 = (1+Prow)*S(Iy)*Biomass(Iy);
   Term2 = Prow*S(Iy)*S(Iy-1)*Biomass(Iy-1);
   Term3 = Prow*Weight*S(Iy)*Rec(Lag1);
   Biomass(Iy+1) = Term1 - Term2 - Term3 + Rec(Lag);
   //std::cout << Iy+1 << " " <<  Biomass(Iy+1) << "\n";
   Prior += square(CatHat(Iy)-Catches(Iy))/(2.0*0.2*0.2);
  }

 obj_fun = Prior;
 int SurveyY;
 for (int Iy=0;Iy<Nsurvey;Iy++)
  {
   SurveyY = SurveyYear(Iy);
   obj_fun += 0.5*square(Biomass(SurveyY)-AbundEst(Iy))/square(AbundSD(Iy));
  }

 for (int Iy=Nyear;Iy<Yfinal-1;Iy++)
  {
   // Survival and recruitment
   S(Iy) = Surv*(1-TheCatch/Biomass(Iy));
   Rec(Iy) = 4*Steep*R0*Biomass(Iy)/Kpar/((1-Steep)+(5*Steep-1)*Biomass(Iy)/Kpar);

   // Lag to recruitment
   if (Iy+1 - 5 < 0) Lag = 0; else Lag = Iy+1 - 5;
   if (Iy - 5 < 0) Lag1 = 0; else Lag1 = Iy - 5;

   // Update dynamics
   Term1 = (1+Prow)*S(Iy)*Biomass(Iy);
   Term2 = Prow*S(Iy)*S(Iy-1)*Biomass(Iy-1);
   Term3 = Prow*Weight*S(Iy)*Rec(Lag1);
   Biomass(Iy+1) = Term1 - Term2 - Term3 + Rec(Lag);
  }

  obj_fun += dummy*dummy;

  REPORT(obj_fun);
  REPORT(Biomass);
  ADREPORT(Steep);

  return(obj_fun);
}
