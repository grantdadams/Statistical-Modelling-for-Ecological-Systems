################################################################################

setwd("D:\\courses\\FISH 559_20\\Homes\\AHome4\\Solution\\")

require(TMB)
library(adnuts)

# =================================================================================================================

MCMCNaive <- function(model,covar,xxx,mult,Nreps=22000,Nburns=2000,Nevery=10)
{
  library(mvtnorm)
  
  Npars <- length(xxx)
  Nout <- Nreps
  Outputs <- matrix(0,nrow=Nout,ncol=Npars)
  ObjFn <- rep(NA,length=Nout)
  
  # Counters
  ichk <- 0
  jchk <- 0
  
  # Initialize
  Theta <- xxx
  DeltaInit <- 0.1
  Delta <- DeltaInit * xxx
  print(Theta)
  gold <- exp(-1*model$fn(Theta))
  print("gold")
  print(log(gold))
  
  Iout <- 0
  for (Irep in 1:Nreps)
  {
    
    # do for each parameter
    asave <- Theta
    Theta <- rmvnorm(1, mean=asave, sigma=covar*mult)
    g1 <- exp(-1*model$fn(Theta))
    #print(log(g1))
    
    RND <-runif(1,0,1)
    if (g1/gold > RND)
    { gold <- g1; ichk <- ichk+1 }
    else
    { Theta <- asave; jchk <- jchk + 1 } 
    
    if (Irep <= Nburns) 
      if (Irep %% Nevery == 0)
      {
        if (ichk > jchk)
          mult <- mult * 1.05
        else 
          mult <- mult * 0.95
        ichk <- 0
        jchk <- 0
      }  
    
    # end of current replicate
    if (Irep %% Nevery == 0)
      if (Irep > Nburns)
      { 
        Iout <- Iout + 1 
        Outputs[Iout,] <- Theta 
        ObjFn[Iout] <- log(gold)
      }
    if (Irep %% 1000 == 0) print(Irep)  
    
  }
  
  Outs <- list()
  Outs$Outs <- Outputs
  Outs$Outs <- Outs$Outs[1:Iout,]
  Outs$ObjFn <- ObjFn[1:Iout]
  return(Outs)
}

################################################################################
RunOne <- function(post,ModelName,data,Remove=100,DoPlots=F)
 {
  model <- MakeADFun(data, parameters, DLL=ModelName,silent=T,map=map)
  NpostSamp <- length(post[,1])
  Biomasses <- matrix(0,nrow=NpostSamp,ncol=data$Nyear+data$Nproj+1)
  for (IP in 1:NpostSamp)
   {
    xx <- model$fn(post[IP,])
    Biomasses[IP,] <- model$report()$Biomass
   }  
  
  # Reference is to 2002 not 2001!
  CurrentDepl <- Biomasses[,31]/post[,2]*100
  FutureDepl <- Biomasses[,41]/post[,2]*100
  if (DoPlots)
   {
    hist(post[,2],main="",xlab="Carrying Capacity")
    hist(post[,1],main="",xlab="Productivity")
    hist(CurrentDepl,main="",xlab="2002 depletion")
    hist(FutureDepl,main="",xlab="2012 depletion")
    Years <- 1:41
    for (II in 1:length(Biomasses[,1])) Biomasses[II,] <- Biomasses[II,]/Biomasses[II,1]*100
    Resa <- matrix(NA,nrow=41,ncol=19)
    for (II in 1:41)
      Resa[II,] <- quantile(Biomasses[,II],prob=c(0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95))
    plot(Years,Resa[,3],xlab="Year",ylab="Relative biomass",ylim=c(0,max(Resa)*1.1))
    polygon(c(Years,rev(Years)),c(Resa[,1],rev(Resa[,19])),col="gray90")
    polygon(c(Years,rev(Years)),c(Resa[,2],rev(Resa[,18])),col="gray80")
    polygon(c(Years,rev(Years)),c(Resa[,3],rev(Resa[,17])),col="gray70")
    polygon(c(Years,rev(Years)),c(Resa[,4],rev(Resa[,16])),col="gray60")
    polygon(c(Years,rev(Years)),c(Resa[,5],rev(Resa[,15])),col="gray50")
    polygon(c(Years,rev(Years)),c(Resa[,6],rev(Resa[,14])),col="gray40")
    polygon(c(Years,rev(Years)),c(Resa[,7],rev(Resa[,13])),col="gray30")
    polygon(c(Years,rev(Years)),c(Resa[,8],rev(Resa[,12])),col="gray20")
    polygon(c(Years,rev(Years)),c(Resa[,9],rev(Resa[,11])),col="gray10")
    lines(Years,Resa[,10],lwd=2)
  } 
  
  Use <- FutureDepl > 50
  Prob <- length(FutureDepl[Use])/length(FutureDepl)
  return(Prob)
}

#----------------------------------------------------------------------------------------------------------

Solve<-function(post,ModelName,data,MinC=0,MaxC=200)
{
  data$Nproj = 10
  NsumMat <- matrix(0,nrow=100,ncol=2)
  windows(height=8,width=11)
  par(mfrow=c(2,3))
  for (II in 1:100)
   {
    Ctarg <- II
    data$TheCatch = Ctarg
    probb <- RunOne(post,ModelName,data,DoPlots=F)
    NsumMat[II,1] <- Ctarg
    NsumMat[II,2] <- probb
   }
  plot( NsumMat[,1], NsumMat[,2],xlab="catch",ylab="probability",type='l',lwd=1,xaxs="i",yaxs="i")
  abline(h=0.6)
  for (II in 1:20)
  {
    Ctarg <- (MinC+MaxC)/2.0
    data$TheCatch = Ctarg
    probb <- RunOne(post,ModelName,data,DoPlots=F)
    if (probb > 0.6) 
      MinC <- Ctarg
    else
      MaxC <- Ctarg 
  }
  cat(round(MinC,2)," ",round(MaxC,2)," ",round(Ctarg,2)," ",round(probb,3),"\n")
  points(Ctarg,probb,pch=16,cex=2)
  probb <- RunOne(post,ModelName,data,DoPlots=T)
}

################################################################################

Nyear <- 30
Catches <- read.csv("HWK4.CSV",nrow=Nyear,skip=1,head=F)[,2]
print(Catches)
Abund <- read.csv("HWK4.CSV",skip=32,nrow=6,head=F)
SurveyYear <-Abund[,1]-1
AbundEst <- Abund[,2]
AbundSD <- Abund[,3]
Nsurvey=length(AbundEst)
print(AbundEst)

DoMCMC <- F
DoSolve <- T
PrintAll <- T

################################################################################
# Schaefer model
################################################################################

data=list(Nyear=Nyear,Catches=Catches,Nsurvey=Nsurvey,SurveyYear=SurveyYear,AbundEst=AbundEst,AbundSD=AbundSD,Nproj=1,TheCatch=0)
parameters=list(dummy=0,Logr=-1,K=1200,Fval=rep(-1,Nyear-1))

#print(data)
#print(parameters)

compile("Schaefer.cpp")
dyn.load(dynlib("Schaefer"))

# test code - for checking for minimization
map<-list(Logr=factor(NA),K=factor(NA),Fval=rep(factor(NA),Nyear-1))
model <- MakeADFun(data, parameters, DLL="Schaefer",silent=T,map=map)
xx <- model$fn(model$env$last.par)
if (PrintAll==T) cat(xx,model$report()$obj_fun,"\n")

# Now estimate everything
map<-list(dummy=factor(NA))
model <- MakeADFun(data, parameters, DLL="Schaefer",silent=T,map=map,hessian=T)

# Bounds on the parameters
lowbnd = c(-10,500,rep(-20,Nyear))
uppbnd = c(0,1500,rep(-0.01,Nyear))
fit <- nlminb(model$par, model$fn, model$gr, control=list(rel.tol=1e-12,eval.max=100000,iter.max=1000),
              lower=lowbnd,upper=uppbnd)
best <- model$env$last.par.best
if (PrintAll==T) print(best)
if (PrintAll==T) print(fit$objective)
rep <- sdreport(model)
if (PrintAll==T) print(summary(rep))

# MCMC sampling
if (DoMCMC==T)
 {  
  mcmcout <- sample_tmb(obj=model,seeds=1:3,init=list(list(model$env$last.par.best)),iter=25000,thin=25,chains=1,algorithm="NUTS")
  post1 <- extract_samples(mcmcout)
  Nlen <- length(post1[,1])
  par(mfrow=c(2,2))
  plot(1:Nlen,post1[,1])
  plot(1:Nlen,post1[,2])
  plot(1:Nlen,post1[,3])
  plot(1:Nlen,post1[,4])
  save(post1,file="Schaefer.RData")
 }  

# Solve for the critical F
if (DoSolve==T)
 {
  load(file="Schaefer.RData") 
  Nlen <- length(post1[,1])
  Npar <- length(post1[1,])
  windows(height=25,width=40)
  par(mfrow=c(6,6),mar=c(2,4,4,1))
  plot(1:Nlen,post1[,1],ylab="Log(r)")
  plot(1:Nlen,post1[,2],ylab="K")
  for (II in 3:Npar)
    plot(1:Nlen,post1[,II],ylab=paste("F[",II-2,"]",sep=""))
  Solve(post1,"Schaefer",data)
 }  
AA



################################################################################
# Deriso model
################################################################################
 
 data=list(Nyear=Nyear,Catches=Catches,Nsurvey=Nsurvey,SurveyYear=SurveyYear,AbundEst=AbundEst,AbundSD=AbundSD,
           Nproj=1,TheCatch=0,Prow=0.995,Surv=exp(-0.2),Weight=0.5)

 parameters=list(dummy=0,LogitSteep=0.25,K=1400,Fval=rep(-2,Nyear-1))

 #print(data)
 #print(parameters)

 compile("Deriso.cpp")
 dyn.load(dynlib("Deriso"))

 # test code - for checking for minimization
 map<-list(LogitSteep=factor(NA),K=factor(NA),Fval=rep(factor(NA),Nyear-1))
 model <- MakeADFun(data, parameters, DLL="Deriso",silent=T,map=map)
 xx <- model$fn(model$env$last.par)
 if (PrintAll==T) cat(xx,model$report()$obj_fun,"\n")
 
 # Now estimate everything
 map<-list(dummy=factor(NA))
 model <- MakeADFun(data, parameters, DLL="Deriso",silent=T,map=map,hessian=T)
 
 # Bounds on the parameters
 lowbnd = c(-100,500,rep(-20,Nyear-1))
 uppbnd = c(100,1500,rep(-0.01,Nyear-1))
 fit <- nlminb(model$par, model$fn, model$gr, control=list(rel.tol=1e-12,eval.max=100000,iter.max=1000),
               lower=lowbnd,upper=uppbnd)
 best <- model$env$last.par.best
 if (PrintAll==T) print(best)
 if (PrintAll==T) print(fit$objective)
 rep <- sdreport(model)
 if (PrintAll==T) print(summary(rep))
 
 # MCMC sampling
 if (DoMCMC==T)
  {  
   mcmcout <- sample_tmb(obj=model,seeds=1:3,init=list(list(model$env$last.par.best)), iter=25000,thin=25,chains=1,algorithm="NUTS")
   post2 <- extract_samples(mcmcout)
   Nlen <- length(post2[,1])
   par(mfrow=c(2,2))
   plot(1:Nlen,post2[,1])
   plot(1:Nlen,post2[,2])
   plot(1:Nlen,post2[,3])
   plot(1:Nlen,post2[,4])
   save(post2,file="Deriso.RData")
  }  
 
 # Solve for the critical F
 if (DoSolve==T)
  {
   load(file="Deriso.RData") 
   Nlen <- length(post2[,1])
   Npar <- length(post2[1,])
   windows(height=15,width=20)
   par(mfrow=c(6,6),mar=c(2,4,4,1))
   plot(1:Nlen,post2[,1],ylab="Logit(h)")
   plot(1:Nlen,post2[,2],ylab="K")
   for (II in 3:Npar)
     plot(1:Nlen,post1[,II],ylab=paste("F[",II-2,"]",sep=""))
   Solve(post2,"Deriso",data)
 }  
 