setwd("C:\\Courses\\FISH 559_20\\Lectures\\")

Lect21<-function()
{

 library(MASS)
 zz<-sample(c(1,2,3,4,0),size=10000,replace=T,prob=c(1,1,1,1,2))    
 truehist(zz,ymax=2)
 zz<-sample(c(1,2,3,4,0),size=5)
 print(zz)  
 aa<-MultAEP(c(1,1,3),7000) 
 print(aa/sum(aa))

 FileN <-   "Hake13.dat"
 TheData <- scan(FileN,what=list(Year=0,Catch=0,Cpue=0),n=24*3)

 doOrigFitt(TheData)
 
# doBayes(TheData,5)
 doBoot(TheData,5)
 NULL

}

MultAEP<-function(prob,N)
{
 prob <- prob/sum(prob) 
 Accump <- 0; AccumN <- N
 Vec <- rep(0,length(prob))
 for (I in 1:(length(prob)-1))
  if ((Accump < 1) & (AccumN > 0))
  {
    Vec[I] <- rbinom(1,AccumN,prob[I]/(1-Accump))
    AccumN <- AccumN - Vec[I]
    Accump <- Accump + prob[I]
  }
 Vec[length(prob)] <- AccumN
 return(Vec)
 NULL   
}

# ================================================================================================================================

doBayes<-function(TheData,Ngen)
{
 library(MASS)
 Nyears <- length(TheData$Catch)+1  
 par(mfrow=c(2,2))
 BestFit <- doFit(TheData,T)
 BestObj <- exp(-1*(BestFit$Obj+38))
 print(-1*BestObj)

 # Storage
 Nyears <- length(TheData$Catch)+1  
 BioOut <-  matrix(0,Ngen,Nyears)

    
}

# ================================================================================================================================

doOrigFitt<-function(TheData,Nboot)
{
 Nyears <- length(TheData$Catch)+1  
 BioOut <-  matrix(0,Nboot,Nyears)
    
 # Fit the model once   
 par(mfrow=c(2,2))
 BestFit <- doFit(TheData,T)
 Sigma <- BestFit$Sigma
 print(Sigma)
}

# ================================================================================================================================

doBoot<-function(TheData,Nboot)
{
 Nyears <- length(TheData$Catch)+1  
 BioOut <-  matrix(0,Nboot,Nyears)
    
 # Fit the model once   
 par(mfrow=c(2,2))
 BestFit <- doFit(TheData,T)
 Sigma <- BestFit$Sigma
 print(Sigma)

 # Now do the bootstrapping
 NewData <-TheData  
 Ndata <- length(TheData$Cpue)
 par(mfrow=c(5,5))
 for (IBoot in 1:Nboot)
  {
    print(c("Bootstrap",IBoot))
    

    # Store the results
    BioOut[IBoot,] <- BootFit$Biomass

  }
 par(mfrow=c(4,4))
 for (Iyear in 1:Nyears)
  {
    print(Iyear)
    year <-Iyear-1+TheData$Year[1]
    lab1 <- paste("Biomass[",year,"]",sep="")
   
   hist(BioOut[,Iyear],xlim=c(0,4000),xlab=lab1)
#   wid <- width.SJ(BioOut[,Iyear])
   bio.dens <- density(BioOut[,Iyear])
   lines(bio.dens,lty=5,lwd=2,col=5)
  }

 exitA <- NULL
 exitA$best <- BestFit$Biomass
 exitA$Bio <- BioOut
 return(exitA)

}


# ================================================================================================================================

doFit <-function(TheData,Final)
{
 co <- NULL
 co <-TheData
 co$Final <- F
 assign("co",co,pos=1)  
 xinit <- c(log(0.4),log(3500))
 result<- optim(xinit,Funk) 
 finpar<-c(exp(result$par[1]),exp(result$par[2]))
 SS <- Schaefer(finpar[1],finpar[2],TheData$Year,TheData$Catch,TheData$Cpue,length(TheData$Catch),Final)
 return(SS)
} 

# ================================================================================================================================

Schaefer<-function(r,K,Years,Catch,Cpue,Nyear,Final)
 {

  # Do a projection
  Biomass <- rep(0,Nyear+1)
  Biomass[1] <- K
  for (Year in 1:Nyear)
   {
     Biomass[Year+1] <- Biomass[Year]+r*Biomass[Year]*(1.0-Biomass[Year]/K) - Catch[Year]
     if (Biomass[Year+1] < 0.001) Biomass[Year+1] <- 0.001
   }
 
 # Find the MLE for q
 qbar <- 0; npnt <- 0
 for (Year in 1:Nyear)
  if (Cpue[Year] > 0)
   { npnt <- npnt + 1; qbar <- qbar + log(Cpue[Year]/Biomass[Year]) }
 qbar <- exp(qbar / npnt)

 SS <- 0
 CpuePred <- NULL
 Residual <- NULL
 for (Year in 1:Nyear)
  if (Cpue[Year] > 0)
    {
      CpuePred[Year] <- qbar*Biomass[Year]
      Residual[Year] <- log(Cpue[Year]) - log(qbar*Biomass[Year])
     SS <- SS + Residual[Year]^2 
    }
 Sigma <- sqrt(SS/npnt)

 # Objective function
 Obj <- npnt*log(Sigma) + npnt / 2.0

 if (Final)
  {
   ymax <- max(Cpue,CpuePred)*1.1
   plot(Years,Cpue,xlab="Year",ylab="Cpue",ylim=c(0,ymax),pch=16)
   lines(Years,CpuePred)
   ymax <- max(Biomass)*1.1
   plot(c(Years,Years[Nyear]+1),Biomass,xlab="Year",ylab="Biomass",ylim=c(0,ymax),pch=16)
  }
# print(Obj)


 ZZ <- NULL
 ZZ$Obj <- Obj
 ZZ$Biomass <- Biomass
 ZZ$pars <- c(r,qbar,K)
 ZZ$Sigma <- Sigma 
 ZZ$CpuePred <- CpuePred
 ZZ$Residual <- Residual
 return(ZZ)

 }

Funk <- function(x)
{
 p <- co
 r <- exp(x[1]); K <- exp(x[2])
 ZZ <- Schaefer(r,K,p$Year,p$Catch,p$Cpue,length(p$Catch),p$Final)
 return(ZZ$Obj) 
}

# ================================================================================================================================


Lect21()
