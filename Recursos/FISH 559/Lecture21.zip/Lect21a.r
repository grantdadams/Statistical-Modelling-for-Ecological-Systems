

# Inverse-cumulative method 
Case1<-function()
{
 par(mfrow=c(2,2))  
 x <- seq(0,pi,length=100)
 y <- sin(x)/2
 plot(x,y,lty=1,lwd=3,type='l',yaxs='i',ylim=c(0,1))
 x <- c(x,x[0])
 y <- c(y,y[0])
 polygon(x,y,density=10,col=3)
 y2 <- (cos(0)-cos(x))/2
 lines(x,y2,lwd=5,col=5)
 val <- runif(100000,0,2)
 val <- cos(0)-val
 val2 <- acos(val)
 truehist(val2,ymax=1,xlab="x")

 par(mfrow=c(2,2))  
 yy<-rep(0,length=100)
 yy[1] <- y[1]
 for (I in 2:100)
  yy[I] <- yy[I-1]+y[I]
 yy <- yy / yy[100]

 plot(x,y,lty=1,lwd=3,type='l',yaxs='i',ylim=c(0,1),xaxs='i')
 polygon(x,y,density=10,col=3)
 lines(x,yy,lwd=5,col=5)
 x2 <- c(1,1,0)
 y2 <- c(0,0.23,0.23)
 lines(x2,y2,lty=1,lwd=5,col=1)
}

# Accept-reject sampling
Case2<-function()
{
 par(mfrow=c(2,2))  
 x <- seq(0,pi,length=100)
 y <- sin(x)/2
 plot(x,y,lty=1,lwd=3,type='l',yaxs='i',ylim=c(0,1))
 x <- c(x,x[0])
 y <- c(y,y[0])
 polygon(x,y,density=10,col=3)

 Nsim <- 10000
 val2 <- NULL
 Ntry <- 0
 for (Isim in 1:Nsim)
  {
    NotOk <- T
    while(NotOk)
     {  
      xx <- runif(1,0,pi)
      Ntry <- Ntry + 1
      z <- runif(1,0,1)
      if (sin(xx)/2>z) NotOk <- F
     }
    val2 <- c(val2,xx)
  }
 truehist(val2,ymax=1,xlab="x")
 print(Ntry)
}   

# SIR sampling
Case3<-function()
{
 par(mfrow=c(2,2))  
 x <- seq(0,pi,length=100)
 y <- sin(x)/2
 plot(x,y,lty=1,lwd=3,type='l',yaxs='i',ylim=c(0,1))
 x <- c(x,x[0])
 y <- c(y,y[0])
 polygon(x,y,density=10,col=3)

 Nsim <- 30000
 xx <- runif(Nsim,0,pi)
 yy <- sin(xx)
 val2 <- sample(xx,size=10000,prob=yy,replace=T)
 truehist(val2,ymax=1,xlab="x")
}
    
 library(MASS)
 Case1()   
 Case2()   
 Case3()    

### How to generate from a multivariate distribution
par(mfrow=c(2,2), mar=c(3,3,2,0), mgp=c(1.25,0.25,0), tck=-0.02)
DF = 100
N = 1e5
Corr = 0.75

# Multivariate normal
library("mvtnorm")
Mvnorm = rmvnorm(n=N, mean=c(0,0), sigma=matrix(c(1,Corr,Corr,1),ncol=2))
plot(x=Mvnorm[,1], y=Mvnorm[,2])

# Multivariate t distribution
Mvt = rmvt(n=N, mean=c(0,0), sigma=matrix(c(1,Corr,Corr,1),ncol=2), df=DF)
plot(x=Mvt[,1], y=Mvt[,2])

# Multivariate t distribution
# Uses package Copula
# Requires R v. 2-14-2 or higher
# NOTE: This may only be approximate
library("copula")
library("gplots")
norm.cop <- normalCopula(Corr, dim=2, dispstr="un")
Rcopula <- rCopula(N, norm.cop)
# In uniform space
  cor(Rcopula[,1],Rcopula[,2])
# In t-space
  cor(qt(Rcopula[,1],df=DF),qt(Rcopula[,2],df=DF))
plot(x=qt(Rcopula[,1],df=DF), y=qt(Rcopula[,2],df=DF))

#### Multivariate poisson distribution
# NOTE: This may only be approximate
Mean1 = 3
Mean2 = 3
X = qpois(p=Rcopula[,1],lambda=Mean1)
Y = qpois(p=Rcopula[,2],lambda=Mean2)
# In poisson-space
  mean(X)
  mean(Y)
  cor(X,Y)
hist2d(x=X, y=Y, xlim=range(X), ylim=range(Y), nbins=c(diff(range(X))+1,diff(range(Y))+1))

