setwd("D:\\courses\\FISH 559_20\\Homes\\AHome2\\")

#==========================================================================================

require(TMB)
compile("Home2.cpp")
dyn.load(dynlib("Home2"))

################################################################################

# Read in the data
Nlen <- scan("Home2.dat",skip=1,n=1,quiet=T)
MidLen <- scan("Home2.dat",skip=3,n=Nlen,quiet=T)
UpLen <- scan("Home2.dat",skip=5,n=Nlen,quiet=T)
Ndata <- scan("Home2.dat",skip=7,n=1,quiet=T)
TheData <- matrix(scan("Home2.dat",skip=10,n=Ndata*3,quiet=T),ncol=3,byrow=T)
LenRel <- TheData[,1]
TimeAtLiberty <- TheData[,2]
LenRec <- TheData[,3]
MaxTimeAtLib <- max(TimeAtLiberty)

# parameter to vary
MaxTimeAtLibInLike <- 1000

################################################################################

# Data vector
data <- list(Nlen=Nlen,Ndata=Ndata,MidLen=MidLen,UpLen=UpLen,LenRel=LenRel,TimeAtLiberty=TimeAtLiberty,LenRec=LenRec,MaxTimeAtLib=MaxTimeAtLib,MaxTimeAtLibInLike= MaxTimeAtLibInLike)
#print(str(data))

parameters <- list(dummy=0,alpha=15,beta=0.7,logSigma=2)
#map <- list(alpha=factor(NA),beta=factor(NA),logSigma=factor(NA))
map <- NULL


################################################################################

model <- MakeADFun(data, parameters, map=map, DLL="Home2",silent=T,hessian=T)

# Actual minimzation (with some "Bonus" parameters from nlminb)
fit <- nlminb(model$par, model$fn, model$gr, control=list(eval.max=100000,iter.max=1000))
best <- model$env$last.par.best
print("best")
print(best)
model$fn(best)

# Asymptotic variances
rep <- sdreport(model)
print(summary(rep))
# Variance-covariance matrix
print(solve(model$he()))


# Data vector
data <- list(Nlen=Nlen,Ndata=Ndata,MidLen=MidLen,UpLen=UpLen,LenRel=LenRel,TimeAtLiberty=TimeAtLiberty,LenRec=LenRec,MaxTimeAtLib=MaxTimeAtLib,MaxTimeAtLibInLike=1)
#print(str(data))

parameters <- list(dummy=0,alpha=15,beta=0.7,logSigma=2)
#map <- list(alpha=factor(NA),beta=factor(NA),logSigma=factor(NA))


################################################################################

model <- MakeADFun(data, parameters, map=map, DLL="Home2",silent=T,hessian=T)

# Actual minimzation (with some "Bonus" parameters from nlminb)
fit <- nlminb(model$par, model$fn, model$gr, control=list(eval.max=100000,iter.max=1000))
best <- model$env$last.par.best
print("best")
print(best)
model$fn(best)

# Asymptotic variances
rep <- sdreport(model)
print(summary(rep))

