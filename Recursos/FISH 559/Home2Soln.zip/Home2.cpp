#include <TMB.hpp>

template <class Type> Type square(Type x){return x*x;}

template<class Type>
Type objective_function<Type>::operator() ()
{
  DATA_INTEGER(Nlen)
  DATA_INTEGER(Ndata)
  DATA_VECTOR(MidLen)
  DATA_VECTOR(UpLen)
  DATA_IVECTOR(LenRel)
  DATA_IVECTOR(TimeAtLiberty)
  DATA_IVECTOR(LenRec)
  DATA_INTEGER(MaxTimeAtLib)
  DATA_INTEGER(MaxTimeAtLibInLike)
  // End of data section

  PARAMETER(dummy);
  PARAMETER(alpha);
  PARAMETER(beta);
  PARAMETER(logSigma);
  Type sigma = exp(logSigma);
  // End of parameter section

  matrix<Type> X(Nlen,Nlen);                                           // Transition matrix
  matrix<Type> Y(Nlen,Nlen);                                           // Temporary transition matrix
  matrix<Type> Z(Nlen,Nlen);                                           // Temporary transition matrix
  array<Type> SuperX(MaxTimeAtLib,Nlen,Nlen);                          // For storage
  Type obj_fun;                                                        // Objective function
  Type Pred;                                                           // Expected mean length
  Type Accum;                                                          // Acumatot
  Type YY;                                                              // Temp
  Type Val;                                                            // Another temp
  Type Prob;                                                           // And another one

  // End of specifications section
  // =============================

  // Develop the transition matrix
  X.setZero();
  for (int Ilen=0;Ilen<Nlen-1;Ilen++)
   {
    Pred = alpha + beta*MidLen(Ilen);
    Accum = 0;
    for (int Jlen=Ilen;Jlen<Nlen-1;Jlen++)
     {
      YY = (UpLen(Jlen)-Pred)/sigma;
      Val = pnorm(YY,Type(0),Type(1));
      X(Ilen,Jlen) = Val - Accum;
      Accum = Val;
     }
    X(Ilen,Nlen-1) = 1.0-Val;
   }
  X(Nlen-1,Nlen-1) = 1;

  // Compute matrix by step
  for (int Ilen=0; Ilen<Nlen;Ilen++)
   for (int Jlen=0; Jlen<Nlen;Jlen++)
    SuperX(0,Ilen,Jlen) = X(Ilen,Jlen);
  for (int Icnt=1;Icnt<MaxTimeAtLib;Icnt++)
   {
    for (int Ilen=0; Ilen<Nlen;Ilen++)
     for (int Jlen=0; Jlen<Nlen;Jlen++)
      Y(Ilen,Jlen) =  SuperX(Icnt-1,Ilen,Jlen);
    Z = atomic::matmul(Y,X);
    for (int Ilen=0; Ilen<Nlen;Ilen++)
     for (int Jlen=0; Jlen<Nlen;Jlen++)
      SuperX(Icnt,Ilen,Jlen) = Z(Ilen,Jlen);
   }

  // Likelihood function
  obj_fun = 0;
  for (int Icnt=0;Icnt<Ndata;Icnt++)
   if (TimeAtLiberty(Icnt) > 0 & TimeAtLiberty(Icnt) <= MaxTimeAtLibInLike)
    {
     Prob = SuperX(TimeAtLiberty(Icnt)-1,LenRel(Icnt)-1,LenRec(Icnt)-1);
     obj_fun += log(Prob+1.0e-20);
    }
  ;
  //obj_fun
  REPORT(obj_fun);

  obj_fun = dummy*dummy - obj_fun;

  REPORT(X);
  REPORT(SuperX);
  ADREPORT(sigma);

  return(obj_fun);

}
