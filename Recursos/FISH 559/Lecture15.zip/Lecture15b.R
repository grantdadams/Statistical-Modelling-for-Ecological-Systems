library("rstan")
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())

x <- rnorm(100,1,2)
y <- 5 + 2*x + rnorm(100,0,2)
plot(x,y)
setwd("D:\\courses\\FISH 559_20\\Lectures\\Stan\\")


reg_data <- list(x=x,y=y,N=100)

# one chain - note the list of lists for inits
inits1 <- list(alpha=2,beta=1,sigma=0.5)
inits <- list(inits1)
reg_data <- list(x=x,y=y,N=100)
  
fit <- stan(file = 'Regression.stan', data = reg_data, 
              iter = 1000, chains = 2,verbose=F,fit=T)
print(fit)
# Extract just alpha and beta
la2 <-extract(fit, pars=c("alpha","beta"),permuted = FALSE)
#print(la2)
plot(fit)
print(summary(fit))
traceplot(fit)  
XX <- As.mcmc.list(fit)

stan_diag(fit)
stan_par(fit,par=c("alpha"))
stan_hist(fit,par=c("alpha","beta"))
stan_scat(fit,par=c("alpha","beta"))
stan_ac(fit,par=c("alpha","beta"))
stan_dens(fit,par=c("alpha","beta"))
