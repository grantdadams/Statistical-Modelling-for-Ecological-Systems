library("rstan")
rstan_options(auto_write = TRUE)
options(mc.cores = parallel::detectCores())

setwd("D:\\courses\\FISH 559_20\\Lectures\\Stan\\")



 Analyze <- function()
  {
   Npop <- 20
   Nsamp <- 15
   TheData <- read.table("Ex15d.DAT",header=F)
   Index <- TheData[,1]
   Lengths <- TheData[,2]
   Weights <- TheData[,3]
   
   the_data <- list(Index=Index,Lengths=Lengths,Weights=Weights,Npop=Npop,Nsamp=Nsamp,N=Nsamp*Npop)
   inits1 <- XXXX
   inits <- list(inits1)

   fit <- stan(file = 'Ex15dclass.stan', data = the_data, 
               iter = 10000, chains = 1,init=inits,verbose=F)
   la <- extract(fit,permuted = TRUE)
   par(mfrow=c(2,2))
   hist(la$mean_alpha)
   hist(la$mean_beta)
   
 }
 
 Fit <- Analyze()
 
 print(Fit)
 